const getAllFormacion = require('./getAllFormacion.js');
const insertLegajoFormacion = require('./insertLegajoFormacion.js');
const getAllFormacionLegajo = require('./getAllFormacionlegajo.js');


module.exports={
    getAllFormacion,
    insertLegajoFormacion,
    getAllFormacionLegajo
}