const pool = require('../../database/connection.js');

module.exports = async(req,res)=>{
    //INSERTA EN LEGAJO FORMACION

    const{idLegajo, idFormacion} = req.body;
    console.log('que trae idLegajo: ', idLegajo);
    console.log('que trae idFormacion: ', idFormacion);

    try{

        let armaquery = `INSERT INTO legajo_formacion(id_legajo, id_formacion) VALUES(
            ${idLegajo}, ${idFormacion});
        `;

        const [result] = await pool.query(armaquery);

        console.log('que trae result insertLegajoFormacion: ', result);

        res.status(200).json({
            message:"Se agrega formacion a legajo correctamente",
            result:result
        });
        
    }catch(error){
        res.status(400).send(error.message);
    }

};