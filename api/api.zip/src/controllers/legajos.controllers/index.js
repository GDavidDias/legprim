const getAllLegajosDocente = require('./getAllLegajosDocente.js');

module.exports={
    getAllLegajosDocente
}