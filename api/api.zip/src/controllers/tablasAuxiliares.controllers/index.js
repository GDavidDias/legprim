const getAllAlcance = require('./getAllAlcance');
const getAllCategorias = require('./getAllCategorias');
const getAllEvaluacion = require('./getAllEvaluacion');
const getAllInstitucion = require('./getAllInstitucion');
const getAllModalidad = require('./getAllModalidad');
const getAllNivel = require('./getAllNivel');


module.exports={
    getAllAlcance,
    getAllCategorias,
    getAllEvaluacion,
    getAllInstitucion,
    getAllModalidad,
    getAllNivel
};