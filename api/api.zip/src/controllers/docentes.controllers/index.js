const getAllDocentes = require('./getAllDocentes.js');

module.exports={
    getAllDocentes
}